Unrestricted policy files.
NOTE- The unrestricted policy files provided here will work with all 
IBM Java SDKs version 1.4.2 and higher.